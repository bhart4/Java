package orchestration;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import events.AbstractEvent;
import events.EventFactory;
import events.EventMessage;
import events.EventType;
import pubSubServer.AbstractChannel;
import pubSubServer.ChannelAccessControl;
import pubSubServer.ChannelDiscovery;
import pubSubServer.ChannelPoolManager;
import pubSubServer.SubscriptionManager;
import publishers.AbstractPublisher;
import publishers.PublisherFactory;
import publishers.PublisherType;
import states.subscriber.StateName;
import strategies.publisher.StrategyName;
import subscribers.AbstractSubscriber;
import subscribers.SubscriberFactory;
import subscribers.SubscriberType;

public class Orchestration {

	public static void main(String[] args) {

		int publisherIdCount;
		int subscriberIdCount;

		List<AbstractPublisher> listOfPublishers = new ArrayList<>();
		List<AbstractSubscriber> listOfSubscribers = new ArrayList<>();
		Orchestration testHarness = new Orchestration();

		try {
			listOfPublishers = testHarness.createPublishers();
			listOfSubscribers = testHarness.createSubscribers();

			List<AbstractChannel> channels = ChannelDiscovery.getInstance().listChannels();
			// For demonstration purposes only
			try {
				BufferedReader initialChannels = new BufferedReader(new FileReader(new File("Channels.chl")));
				List<String> channelList = new ArrayList<String>();
				String line = "";
				while ((line = initialChannels.readLine()) != null) {
					channelList.add(line);
				}
				int subscriberIndex = 0;
				for (AbstractSubscriber subscriber : listOfSubscribers) {

					subscriber.subscribe(channelList.get(subscriberIndex % channelList.size()));
					subscriberIndex++;
				}
				initialChannels.close();
			} catch (IOException ioe) {
				System.out.println("Loading Channels from file failed proceeding with random selection");
				for (AbstractSubscriber subscriber : listOfSubscribers) {
					int index = (int) Math.round((Math.random() * 10)) / 3;
					SubscriptionManager.getInstance().subscribe(channels.get(index).getChannelTopic(), subscriber);
				}
			}
			for (AbstractPublisher publisher : listOfPublishers) {

				publisher.publish();
			}

		} catch (IOException ioe) {
			System.out.println(ioe.getMessage());
			System.out.println("Will now terminate");
			return;
		}
		for (AbstractPublisher publisher : listOfPublishers) {
			publisher.publish();
		}

		try {
			BufferedReader orchestration = new BufferedReader(new FileReader(new File("test.txt")));
			String readIn = orchestration.readLine();

			while (readIn != null) {

				try {

					StringTokenizer tokenizer = new StringTokenizer(readIn);
					String word = tokenizer.nextToken();

					// if only id is given create publisher with said id
					if (tokenizer.countTokens() == 1 && word.equals("PUB")) {

						int publisherID = Integer.parseInt(tokenizer.nextToken());

						// create publisher of default type and strategy
						AbstractPublisher newPublisher = PublisherFactory.createPublisher(PublisherType.values()[1],
								StrategyName.values()[2]);

						newPublisher.setID(publisherID);

						listOfPublishers.add(newPublisher);

					// publish events for publisher with matching id 
					} else if (tokenizer.countTokens() == 5 && word.equals("PUB")) {

						int publisherID = Integer.parseInt(tokenizer.nextToken());
						String channelName = tokenizer.nextToken();
						String eventType = tokenizer.nextToken();
						String eventMessageHeader = tokenizer.nextToken();
						String eventMessagePayload = tokenizer.nextToken();

						// create EventType Object
						EventType newType;

						switch (eventType) {

						case "TypeA":
							newType = EventType.values()[1];
						case "TypeB":
							newType = EventType.values()[0];
						default:
							newType = EventType.values()[2];
						}

						// create Event Message object
						EventMessage newMessage = new EventMessage(eventMessageHeader, eventMessagePayload);
						AbstractEvent newEvent = EventFactory.createEvent(newType, publisherID, newMessage);

						for (AbstractPublisher publisher : listOfPublishers) {

							if (publisher.getID() == publisherID) {
								publisher.publish(newEvent);
							}
						}

						// subscribe subscriber to desired channel
					} else if (tokenizer.countTokens() == 2 && word.equals("SUB")) {

						int subscriberID = Integer.parseInt(tokenizer.nextToken());
						String channelName = tokenizer.nextToken();

						ChannelPoolManager Pool = ChannelPoolManager.getInstance();

						if (!Pool.listChannels().contains(channelName)) {
							throw new IllegalArgumentException("Channel Does Not Exist");
						}

						for (AbstractSubscriber subscriber : listOfSubscribers) {

							if (subscriber.getID() == subscriberID) {
								subscriber.subscribe(channelName);
								break;
							}
						}

						// block subscriber from a channel 
					} else if (tokenizer.countTokens() == 2 && word.equals("BLOCK")) {

						int subscriberID = Integer.parseInt(tokenizer.nextToken());
						String channelName = tokenizer.nextToken();

						ChannelAccessControl accessManager = ChannelAccessControl.getInstance();

			
						for (AbstractSubscriber subscriber : listOfSubscribers) {

							if (subscriber.getID() == subscriberID)
								accessManager.blockSubcriber(subscriber, channelName);

						}

						// unblock a subscriber from a channel
					} else if (tokenizer.countTokens() == 2 && word.equals("UNBLOCK")) {

						int subscriberID = Integer.parseInt(tokenizer.nextToken());
						String channelName = tokenizer.nextToken();

						ChannelAccessControl accessManager = ChannelAccessControl.getInstance();

						for (AbstractSubscriber subscriber : listOfSubscribers) {

							if (subscriber.getID() == subscriberID)
								accessManager.unBlockSubscriber(subscriber, channelName);

						}

					} else {
						throw new IllegalArgumentException("Illegal arguments formatting.");

					}

				} catch (IllegalArgumentException e) {
					System.out.println("Illegal arguments supplied ");
				}
				// read in the next line
				readIn = orchestration.readLine();

			}

		} catch (IOException e) {
			System.out.println("buffered reader does not work  ");

		}

	}

	private List<AbstractPublisher> createPublishers() throws IOException {
		List<AbstractPublisher> listOfPublishers = new ArrayList<>();
		AbstractPublisher newPub;
		BufferedReader StrategyBufferedReader = new BufferedReader(new FileReader(new File("Strategies.str")));

		while (StrategyBufferedReader.ready()) {
			String PublisherConfigLine = StrategyBufferedReader.readLine();
			String[] PublisherConfigArray = PublisherConfigLine.split("\t");
			int[] PublisherConfigIntArray = new int[2];
			for (int i = 0; i < PublisherConfigArray.length; i++)
				PublisherConfigIntArray[i] = Integer.parseInt(PublisherConfigArray[i]);

			newPub = PublisherFactory.createPublisher(PublisherType.values()[PublisherConfigIntArray[0]],
					StrategyName.values()[PublisherConfigIntArray[1]]);
			listOfPublishers.add(newPub);
		}
		StrategyBufferedReader.close();
		return listOfPublishers;
	}

	private List<AbstractSubscriber> createSubscribers() throws IOException {
		List<AbstractSubscriber> listOfSubscribers = new ArrayList<>();
		AbstractSubscriber newSub;
		BufferedReader StateBufferedReader = new BufferedReader(new FileReader(new File("States.sts")));

		int j = 0;

		while (StateBufferedReader.ready()) {
			String StateConfigLine = StateBufferedReader.readLine();
			String[] StateConfigArray = StateConfigLine.split("\t");
			int[] StateConfigIntArray = new int[2];
			for (int i = 0; i < StateConfigArray.length; i++)
				StateConfigIntArray[i] = Integer.parseInt(StateConfigArray[i]);

			newSub = SubscriberFactory.createSubscriber(SubscriberType.values()[StateConfigIntArray[0]],
					StateName.values()[StateConfigIntArray[1]]);

			newSub.setID(j);

			listOfSubscribers.add(newSub);
			j = j + 1;
		}
		StateBufferedReader.close();
		return listOfSubscribers;
	}

}