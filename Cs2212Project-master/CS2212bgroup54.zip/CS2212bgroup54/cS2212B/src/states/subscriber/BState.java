package states.subscriber;

import events.AbstractEvent;

public class BState implements IState {

	@Override
	public void handleEvent(AbstractEvent event, String channelName) {
	//System.out.println("Subscriber receives event "+ event.getEventID() +" and handles it at state B");
		
	}
	public String getName() {
		return "State B";
	}

}
