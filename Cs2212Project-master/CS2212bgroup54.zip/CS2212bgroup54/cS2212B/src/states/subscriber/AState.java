package states.subscriber;

import events.AbstractEvent;

public class AState implements IState {


	public void handleEvent(AbstractEvent event, String channelName) {
		
		//System.out.println("Subscriber receives event "+ event.getEventID() +" and handles it at state A");
		
		

	}
	public String getName() {
		return "State A";
	}

}
