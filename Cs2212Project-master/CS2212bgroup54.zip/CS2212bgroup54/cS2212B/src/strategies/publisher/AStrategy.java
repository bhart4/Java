package strategies.publisher;

import java.util.ArrayList;
import java.util.List;

import events.AbstractEvent;
import events.EventFactory;
import events.EventMessage;
import events.EventType;
import pubSubServer.ChannelEventDispatcher;
import publishers.AbstractPublisher;

public class AStrategy implements IStrategy {

	public void doPublish(int publisherId) {
		
		List<String> channels = new ArrayList<>();
		
		channels.add("cars");
		channels.add("planes");
		
		ChannelEventDispatcher channelDispatch = ChannelEventDispatcher.getInstance();
		
		// create default message of type a 
		EventMessage newMessage = new EventMessage("New Event soon", "Publisher is working on new content");
		AbstractEvent newEvent = EventFactory.createEvent(EventType.values()[1], publisherId, newMessage);
		
		channelDispatch.postEvent(newEvent, channels);
		
		System.out.println("Publisher " + publisherId + " is publishing event: " + newEvent.getEventID());
		
	}

	@Override
	public void doPublish(AbstractEvent event, int publisherId) {
		
		List<String> channels = new ArrayList<>();
		
		channels.add("cars");
		channels.add("planes");
		
		ChannelEventDispatcher channelDispatch = ChannelEventDispatcher.getInstance();
		
		channelDispatch.postEvent(event, channels);
		
		System.out.println("Publisher " + publisherId + " is publishing event: " + event.getEventID());
	

	}
	public String getName() {
		return "Strategy A";
	}

}
